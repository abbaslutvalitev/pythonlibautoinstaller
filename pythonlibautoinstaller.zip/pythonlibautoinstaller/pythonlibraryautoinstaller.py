from tkinter import Button, Entry, Label, Tk
import pip
import subprocess
import subprocess
import sys
from tkinter import *
from tkinter import messagebox as mb


root = Tk()
root.title("Python librarys auto installer")
root.resizable(0, 0)
warning1 = Label(width=20, text="WARNING!", bg="red")
warning2 = Label(width=50, text="This utility in beta test! May have problems.")
en = Label(width=10, text="Library name: ")
def install(package):
   subprocess.check_call([sys.executable, "-m", "pip", "install", package])
def unistall(package):
   subprocess.check_call([sys.executable, "-m", "pip", "uninstall", package])
libname = Entry(width=20)
def onClick():
   mb.askyesno(message="Do you want to install the given library?")
   if libname.get() == None or libname.get() == "" or libname.get() == " ":
      mb.showerror(message="You did not enter the name of the library")
   else:
      lib = str(libname.get())
      install(lib)
      mb.showinfo(message="Successfully")
def onClick1():
   mb.askyesno(message="Do you want to uninstall the given library?")
   if libname.get() == None or libname.get() == "" or libname.get() == " ":
      mb.showerror(message="You did not enter the name of the library")
   else:
      lib = str(libname.get())
      unistall(lib)
      mb.showinfo(message="Successfully")

installbtn = Button(width=40, text="Install!", command=onClick)
unistallbtn = Button(width=40, text="Unistall!", command=onClick1)

warning1.pack()
warning2.pack()
en.pack()
libname.pack()
installbtn.pack()
unistallbtn.pack()


root.mainloop()






